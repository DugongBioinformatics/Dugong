# Internal functions

#' t-test of rows for arrays with NA values
#'
#' This function performs a t-test by rows
#'
#' @param x Numeric matrix representing the phenotype samples
#' @param y Optional numeric matrix representing the control samples
#' @param mu Number indicating the null hypothesis value to be used when \code{y} is ommited
#' @param alternative Character string indicating the tail to test, either two.sided, greater or less
#' @return A list with two components: \describe{
#' \item{statistic}{t-test statistic}
#' \item{p.value}{p-value}
#' }

f.rtt.na <- function(x, y=NULL, mu=0, alternative="two.sided") {
  largo <- f.rlength.na(x)
  if (is.null(y)) {
    t <- (f.rmean.na(x)-mu)/sqrt(f.rvar.na(x)/largo)
    list(statistic=t, p.value=switch(pmatch(alternative, c("two.sided", "greater", "less")), pt(abs(t), largo-1,lower.tail=F)*2, pt(t, largo-1, lower.tail=F), pt(t, largo-1, lower.tail=T)))
  }
  else {
    largoy <- f.rlength.na(y)
    t <- (f.rmean.na(x)-f.rmean.na(y))/sqrt(((largo-1)*f.rvar.na(x)+(largoy-1)*f.rvar.na(y))/(largo+largoy-2))/sqrt(1/largo+1/largoy)
    list(statistic=t, p.value=switch(pmatch(alternative, c("two.sided", "greater", "less")), pt(abs(t), largo+largoy-2, lower.tail=F)*2, pt(t, largo+largoy-2, lower.tail=F), pt(t, largo+largoy-2, lower.tail=T)))
  }
}

#' Length of rows for arrays with NA values
#'
#' This function report the length of rows of a matrix ignoring the NA values
#'
#' @param x Matrix
#' @return Integer indicating the number of non-NA rows

f.rlength.na <- function(x) {
  r <- x/x
  r[x==0] <- 1
  r[!is.finite(r)] <- 0
  r %*% rep(1, ncol(r))
}

#' Mean of rows for arrays with NA values
#'
#' This function compute the mean by rows ignoring NA values
#'
#' @param x Numeric matrix
#' @return Numeric vector

f.rmean.na <- function(x) {
  largo <- f.rlength.na(x)
  x[is.na(x)] <- 0
  res <- x %*% rep(1, ncol(x)) / largo
  names(res) <- rownames(x)
  res
}

#' Variance of rows for arrays with NA values
#'
#' This function computes the variance by rows ignoring NA values
#'
#' @param x Numeric matrix
#' @return Numeric vector

f.rvar.na <- function(x) {
  ave <- as.vector(f.rmean.na(x))
  pos <- which(is.na(x))
  largo <- f.rlength.na(x)
  x[pos] <- rep(ave, ncol(x))[pos]
  (x-ave)^2 %*% rep(1, ncol(x))/(largo-1)
}

#' Regulon-specific NULL model
#'
#' This function generates the regulon-specific NULL models
#'
#' @param pwnull Numerical matrix representing the null model, with genes as rows (geneID as rownames) and permutations as columns
#' @param groups List containing the regulons
#' @param tnorm Logical, whether the ranking vector should be normally transformed after the copula transformation
#' @param tw Number indicating the exponent for the target pleotropy weight
#' @param lw Number indicating the exponent for the edge likelihood weight
#' @param simsig Logical, whether a symetrical distribution of the signature is used
#' @return A list containing two elements:
#' \describe{
#' \item{groups}{Regulon-specific NULL model containing the enrichment scores}
#' \item{ss}{Direction of the regulon-specific NULL model}
#' }

pwea3NULLgroups <- function(pwnull, groups, tw=1, lw=1) {
  if (is.null(pwnull)) return(NULL)
  if (is.matrix(pwnull)) pwnull <- list(eset=pwnull)
  groups <- updateRegulon(groups)
  groups <- lapply(groups, function(x, lw) {x$likelihood <- x$likelihood^lw; return(x)}, lw=lw)
  if (length(tw)==1) tw <- 1/table(unlist(lapply(groups, function(x) names(x$tfmode)), use.names=F))^tw
  if (is.list(pwnull$eset)) {
    t <- unlist(pwnull$eset, use.names=F)
    dim(t) <- c(length(pwnull$eset[[1]]), length(pwnull$eset))
    rownames(t) <- names(pwnull$eset[[1]])
    colnames(t) <- 1:length(pwnull$eset)
  }
  else t <- pwnull$eset
  t2 <- apply(t, 2, rank)/(nrow(t)+1)*2-1
  t1 <- abs(t2)*2-1
  t1[t1==(-1)] <- 1-(1/length(t1))
  t1 <- qnorm(t1/2+.5)
  t2 <- qnorm(t2/2+.5)
  temp <- lapply(groups, function(x, t1, t2, tw) {
    pos <- match(names(x$tfmode), rownames(t1))
    tw <- tw[match(names(x$tfmode), names(tw))]
    sum1 <- matrix(x$tfmode * tw * x$likelihood, 1, length(x$tfmode)) %*% t2[pos, ]
    ss <- sign(sum1)
    ss[ss==0] <- 1
    sum2 <- matrix((1-abs(x$tfmode)) * tw * x$likelihood, 1, length(x$tfmode)) %*% t1[pos, ]
    return(list(es=as.vector(abs(sum1) + sum2*(sum2>0)) / sum(tw * x$likelihood), ss=ss))
  }, t1=t1, t2=t2, tw=tw)
  es <- t(sapply(temp, function(x) x$es))
  ss <- t(sapply(temp, function(x) x$ss))
  return(list(groups=es, ss=ss))
}

updateRegulon <- function(regul) {
  if (is.null(names(regul[[1]]))) return(lapply(regul, function(x) {tmp <- rep(0, length(x)); names(tmp) <- x; list(tfmode=tmp, likelihood=rep(1, length(tmp)))}))
  if (names(regul[[1]])[1]=="tfmode") return(regul)
  return(lapply(regul, function(x) list(tfmode=x, likelihood=rep(1, length(x)))))
}

ppwea3NULLf <- function(regulon, tw, lw) {
  lapply(regulon, function(x, tw, lw) {
    ww <- x$likelihood^lw*tw[match(names(x$tfmode), names(tw))]
    ww <- ww/max(ww)
    ww <- sqrt(sum(ww^2))
    return(function(x, alternative="greater") {
      x <- x*ww
      p <- switch(pmatch(alternative, c("two.sided", "less", "greater")),
                  pnorm(abs(x), lower.tail=F)*2,
                  pnorm(x, lower.tail=T),
                  pnorm(x, lower.tail=F))
      list(nes=x, p.value=p)
    })
  }, tw=tw, lw=lw)
}

filtro.row.matrix <- function (x, filter) {
  if (is.logical(filter)) 
    largo <- length(which(filter))
  else largo <- length(filter)
  matrix(x[filter, ], largo, ncol(x), dimnames = list(rownames(x)[filter], colnames(x)))
}
