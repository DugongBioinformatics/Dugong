#' Virtual Inference of Protein-activity by Regulon Readout 
#'
#' This function performs VIPER analysis
#'
#' @param eset Dataset with samples in columns and genes in rows
#' @param regulon Regulon object including TFmode and likelihood
#' @param method Character string indicating the method for computing the single samples signature, either scale, rank, mad, ttest or none
#' @param minsize Integer indicating the minimum number of targets allowed per regulon
#' @param adaptive.size Logical, whether the weighting scores should be taken into account for computing the regulon size
#' @param eset.filter Logical, whether the dataset should be limited only to the genes represented in the interactome
#' @param tw Number indicating the power transformation for target weight
#' @param lw Number indicating the power transformation for the likelihood weight
#' @return A matrix of protein activity
#' @examples data(mcf7_cmap2_expset, mcf7_cmap2_tf_regulon)
#' dset <- mcf7dset[, 1:100]
#' tfa <- viper(dset, mcf7regul, method="none")
#' @export

viper <- function(eset, regulon, method=c("scale", "rank", "mad", "ttest", "none")[1], minsize=20, adaptive.size=F, eset.filter=T, tw=.5, lw=1) {
  if (eset.filter) eset <- eset[rownames(eset) %in% unique(c(names(regulon), unlist(lapply(regulon, function(x) names(x$tfmode)), use.names=F))), ]
  cat("\nComputing the association scores\n")
	switch(pmatch(method, c("scale", "rank", "mad", "ttest", "none")),
		tt <- t(scale(t(eset))),
		tt <- t(apply(eset, 1, rank))*punif(length(eset), -.1, .1),
		tt <- t(apply(eset, 1, function(x) (x-median(x))/mad(x))),
		{tt <- sapply(1:ncol(eset), function(i, eset) f.rtt.na(eset[, i]-eset[, -i])$statistic, eset=eset); colnames(tt) <- colnames(eset); rownames(tt) <- rownames(eset)},
		tt <- eset
	)
  regulon <- lapply(regulon, function(x, genes) {
    filtro <- names(x$tfmode) %in% genes
    x$tfmode <- x$tfmode[filtro]
    if(length(x$likelihood)==length(filtro)) x$likelihood <- x$likelihood[filtro]
    return(x)
  }, genes=rownames(eset))
	tw <- 1/table(unlist(lapply(regulon, function(x) names(x$tfmode)), use.names = F))^tw
	if (adaptive.size) regulon <- regulon[sapply(regulon, function(x, tw) {t1 <- tw[match(names(x$tfmode), names(tw))]; sum(x$likelihood*t1/max(x$likelihood*t1))}, tw=tw)>=minsize]
	else regulon <- regulon[sapply(regulon, function(x) length(x$tfmode))>=minsize]
  es <- pwea3NULLgroups(tt, regulon, tw=tw, lw=lw)
  dnull <- ppwea3NULLf(regulon, tw=tw, lw=lw)
  pval <- t(sapply(1:length(dnull), function(i, es, dnull) dnull[[i]](es[i, ])$p.value, es=es$groups, dnull=dnull)) 
  nes <- qnorm(pval, lower.tail=F)*es$ss
  rownames(nes) <- names(regulon)
  colnames(nes) <- colnames(eset)
  return(nes)
}
