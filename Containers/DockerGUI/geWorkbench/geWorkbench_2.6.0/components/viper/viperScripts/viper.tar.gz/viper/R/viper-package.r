#' Virtual Inference of Protein-activity by Regulon Readout (VIPER)
#'
#' This package includes the VIPER algorithm implementation and the signatureDistance function.
#' The function viper transforms a gene expression dataset into a regulator's activity dataset using an appropiate gene regulatory network.
#' The function signatureDistance computes the distance between samples based on a predefined number of genes changing the most between each sample and the remaining dataset.
#' 
#' @name viper-package
#' @docType package
#' @title VIPER: Virtual Inference of Protein-activity by Regulon Readout
#' @author Mariano J. Alvarez \email{malvarez@@c2b2.columbia.edu}
#' @keywords MARINA, master regulator, virtual proteomics, viper
NULL

#' Connectivity map-2 expression dataset for MCF7 breast carcinoma cell line
#' 
#' MCF7-CMAP2 dataset in rank-format. Lowest values indicates downregulation and highest values indicate upregulation of gene expression compared to the vehivle control.
#' 
#' @name mcf7_cmap2_expset
#' @docType data
#' @format Numeric of integer values with 3,095 columns (samples) and 11,792 rows (genes)
#' @references Lamb, J. et al. The Connectivity Map: using gene-expression signatures to connect small molecules, genes, and disease. Science  313:1929–35 (2006)
#' @source http://www.broadinstitute.org/cmap/
#' @keywords datasets
NULL

#' Connectivity map-2 expression dataset for HL60 promyelocytic leukemia cell line
#' 
#' HL60-CMAP2 dataset in rank-format. Lowest values indicates downregulation and highest values indicate upregulation of gene expression compared to the vehivle control.
#' 
#' @name hl60_cmap2_expset
#' @docType data
#' @format Numeric of integer values with 1,229 columns (samples) and 11,793 rows (genes)
#' @references Lamb, J. et al. The Connectivity Map: using gene-expression signatures to connect small molecules, genes, and disease. Science  313:1929–35 (2006)
#' @source http://www.broadinstitute.org/cmap/
#' @keywords datasets
NULL

#' Connectivity map-2 expression dataset for PC3 prostate carcinoma cell line
#' 
#' PC3-CMAP2 dataset in rank-format. Lowest values indicates downregulation and highest values indicate upregulation of gene expression compared to the vehivle control.
#' 
#' @name pc3_cmap2_expset
#' @docType data
#' @format Numeric of integer values with 1,741 columns (samples) and 11,793 rows (genes)
#' @references Lamb, J. et al. The Connectivity Map: using gene-expression signatures to connect small molecules, genes, and disease. Science  313:1929–35 (2006)
#' @source http://www.broadinstitute.org/cmap/
#' @keywords datasets
NULL

#' Breast carcinoma MCF7 transcriptional regulatory network
#' 
#' Gene regulatory model constructed by ARACNe based on the TCGA breast carcinoma RNAseq dataset and the MCF7-CMAP2 dataset
#' 
#' @name mcf7_cmap2_tf_regulon
#' @docType data
#' @format List of 1,741 transcription factor regulons, each one consisting in two vectors, the Mode of Regulation (MoR) and the target confidence (likelihood)
#' @references Lamb, J. et al. The Connectivity Map: using gene-expression signatures to connect small molecules, genes, and disease. Science  313:1929–35 (2006)
#' @references Margolin, A. A. et al. ARACNE: an algorithm for the reconstruction of gene regulatory networks in a mammalian cellular context. BMC bioinformatics 7 Suppl 1, S7 (2006)
#' @keywords datasets
NULL

#' Prostate carcinoma PC3 transcriptional regulatory network
#' 
#' Gene regulatory model constructed by ARACNe based on the Gerard's prostate carcinoma expression dataset and the MCF7-PC3 dataset
#' 
#' @name pc3_cmap2_tf_regulon
#' @docType data
#' @format List of 1,813 transcription factor regulons, each one consisting in two vectors, the Mode of Regulation (MoR) and the target confidence (likelihood)
#' @references Lamb, J. et al. The Connectivity Map: using gene-expression signatures to connect small molecules, genes, and disease. Science  313:1929–35 (2006)
#' @references Margolin, A. A. et al. ARACNE: an algorithm for the reconstruction of gene regulatory networks in a mammalian cellular context. BMC bioinformatics 7 Suppl 1, S7 (2006)
#' @keywords datasets
NULL

#' LAML HL60 transcriptional regulatory network
#' 
#' Gene regulatory model constructed by ARACNe based on the TCGA acute myeloid leukemia RNAseq dataset and the HL60-CMAP2 dataset
#' 
#' @name hl60_cmap2_tf_regulon
#' @docType data
#' @format List of 1,770 transcription factor regulons, each one consisting in two vectors, the Mode of Regulation (MoR) and the target confidence (likelihood)
#' @references Lamb, J. et al. The Connectivity Map: using gene-expression signatures to connect small molecules, genes, and disease. Science  313:1929–35 (2006)
#' @references Margolin, A. A. et al. ARACNE: an algorithm for the reconstruction of gene regulatory networks in a mammalian cellular context. BMC bioinformatics 7 Suppl 1, S7 (2006)
#' @keywords datasets
NULL
