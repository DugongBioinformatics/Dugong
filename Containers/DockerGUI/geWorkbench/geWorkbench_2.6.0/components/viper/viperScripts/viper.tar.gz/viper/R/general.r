# General functions for the VIPER package

#' Median for groups
#'
#' This function computes the median for groups by rows for \code{colnames}-defined groups
#'
#' @param dset Numeric matrix
#' @return Numeric matrix
#' @export

median.group <- function(dset) {
  groups <- colnames(dset)
  res <- NULL
  glev <- unique(groups)
  for (i in 1:length(glev)) res <- cbind(res,apply(as.matrix(dset[,groups==glev[i]]),1,median,na.rm=T))
  colnames(res) <- glev
  rownames(res) <- rownames(dset)
  res
}

#' Mean for groups
#'
#' This function computes the mean for groups by rows for \code{colnames}-defined groups
#'
#' @param dset Numeric matrix
#' @return Numeric matrix
#' @export

mean.group <- function(dset) {
  groups <- colnames(dset)
  glev <- unique(groups)
  repit <- tapply(groups, groups, length)
  res <- dset[,match(names(repit)[repit==1],colnames(dset))]
  for (i in names(repit)[repit>1]) res <- cbind(res,as.matrix(f.rmean.na(as.matrix(dset[,groups==i]))))
  res <- res[,match(glev,c(names(repit)[repit==1],names(repit)[repit>1]))]
  if (is.null(dim(res))) dim(res) <- c(length(res),1)
  colnames(res) <- glev
  rownames(res) <- rownames(dset)
  res
}
