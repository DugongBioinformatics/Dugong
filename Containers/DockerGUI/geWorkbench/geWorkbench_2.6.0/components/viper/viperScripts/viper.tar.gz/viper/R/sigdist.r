#' Signature Distance
#'
#' This function compute a distance matrix based on molecular signatures
#' @param dset Dataset of any type in matrix format, with features in rows and samples in columns
#' @param dset2 Optional Dataset. If provided, distance between columns of dset and dset2 are computed and reported as rows and columns, respectively; if not, distance between all possible pairs of columns from dset are computed
#' @param nn Optional size for the signature
#' @param symmetric Logical, whether a symmetric meassure of association should be used (i.e. absolute value of the enrichment score)
#' @param groups Optional vector indicating the group ID of the samples. If provided, the distance between the groups will be computed
#' @param scale. Logical, whether the data should be scaled
#' @param nes Logical, whether NES instead of a positive distance matrix should be returned
#' @param two.tails Logical, whether a two tails, instead of 1 tail test should be performed
#' @return Distance matrix
#' @examples data(mcf7_cmap2_expset)
#' dset <- mcf7dset[, 1:50]
#' d <- signatureDistance(dset, scale.=F)
#' plot(hclust(d))
#' @export

signatureDistance <- function(dset, dset2=NULL, nn=NULL, symmetric=F, groups=NULL, scale.=T, nes=F, two.tails=T) {
  if (is.null(nn)) nn=round(nrow(dset)/10)
  nn <- round(nn/2)
  d1 <- dset
  if (is.null(dset2)) {
    if (nrow(d1)<(nn*3)) stop("Error, insufficient number of features to perform analysis", call.=F)
    if (!is.null(groups)) d1 <- scaleGroups(dset, groups)
    else if (scale.) d1 <- t(scale(t(dset)))
    d1 <- apply(d1, 2, rank)/(nrow(d1)+1)*2-1
    if (!two.tails) {
      d1 <- abs(d1)*2-1
      d1[d1==(-1)] <- 1-(1/nrow(d1))
    }
    d1 <- qnorm(d1/2+.5)
    if (two.tails) {
      reg <- lapply(1:ncol(d1), function(i, d1, nn) {
        orden <- order(d1[, i])
        sign(d1[orden[c(1:nn, (nrow(d1)-nn+1):nrow(d1))], i])
      }, d1=d1, nn=nn)
    }
    else {
      reg <- lapply(1:ncol(d1), function(i, d1, nn) {
        orden <- order(d1[, i], decreasing=T)
        tmp <- d1[orden[1:(2*nn)], i]
        tmp/tmp
      }, d1=d1, nn=nn)
    }		
    names(reg) <- colnames(d1)
    genes <- unique(unlist(lapply(reg, names), use.names=F))
    d1 <- t(d1[match(genes, rownames(d1)), ])
    reg <- sapply(reg, function(x, genes) x[match(genes, names(x))], genes=genes)
    reg[is.na(reg)] <- 0
    es <- (d1 %*% reg)/sqrt(2*nn)
    offdiag <- rowMeans(cbind(es[lower.tri(es)], t(es)[lower.tri(es)]))
    es[lower.tri(es)] <- offdiag
    es <- t(es)
    es[lower.tri(es)] <- offdiag
    if (nes) return(es)
    if (symmetric) return(as.dist(max(abs(es))-abs(es)))
    return(as.dist(max(es)-es))
  }
  d2 <- dset2
  genes <- rownames(d1)[rownames(d1) %in% rownames(d2)]
  if (length(genes)<(nn*3)) stop("Error, insufficient number of common features to perform analysis", call.=F)
  d1 <- filtro.row.matrix(d1, match(genes, rownames(d1)))
  d2 <- filtro.row.matrix(d2, match(genes, rownames(d2)))
  if (!is.null(groups)) {
    if (length(groups)==2) {d1 <- scaleGroups(dset, groups[[1]]); d2 <- scaleGroups(dset2, groups[[2]])}
    else {d1 <- t(scale(t(dset))); d2 <- t(scale(t(dset2))); warning("Not using groups...Expecting a 2 elements list for groups when dset2 is defined", call.=F)}
  }
  else if (scale.) {d1 <- t(scale(t(dset))); d2 <- t(scale(t(dset2)))}
  d1 <- apply(d1, 2, rank)/(nrow(d1)+1)*2-1
  d2 <- apply(d2, 2, rank)/(nrow(d2)+1)*2-1
  if (!two.tails) {
    d1 <- abs(d1)*2-1
    d1[d1==(-1)] <- 1-(1/nrow(d1))
    d2 <- abs(d2)*2-1
    d2[d2==(-1)] <- 1-(1/nrow(d2))
  }
  d1 <- qnorm(d1/2+.5)
  d2 <- qnorm(d2/2+.5)
  if (two.tails) {
    reg1 <- lapply(1:ncol(d1), function(i, d1, nn) {
      orden <- order(d1[, i])
      sign(d1[orden[c(1:nn, (nrow(d1)-nn+1):nrow(d1))], i])
    }, d1=d1, nn=nn)
    reg2 <- lapply(1:ncol(d2), function(i, d1, nn) {
      orden <- order(d1[, i])
      sign(d1[orden[c(1:nn, (nrow(d1)-nn+1):nrow(d1))], i])
    }, d1=d2, nn=nn)
    names(reg2) <- colnames(d2)
  }
  else {
    reg1 <- lapply(1:ncol(d1), function(i, d1, nn) {
      orden <- order(d1[, i], decreasing=T)
      tmp <- d1[orden[1:(2*nn)], i]
      tmp/tmp
    }, d1=d1, nn=nn)
    reg2 <- lapply(1:ncol(d2), function(i, d1, nn) {
      orden <- order(d1[, i], decreasing=T)
      tmp <- d1[orden[1:(2*nn)], i]
      tmp/tmp
    }, d1=d2, nn=nn)
  }		
  names(reg1) <- colnames(d1)
  names(reg2) <- colnames(d2)
  genes <- unique(unlist(lapply(reg1, names), use.names=F))
  d2 <- t(filtro.row.matrix(d2, match(genes, rownames(d2))))
  reg1 <- sapply(reg1, function(x, genes) x[match(genes, names(x))], genes=genes)
  reg1[is.na(reg1)] <- 0
  genes <- unique(unlist(lapply(reg2, names), use.names=F))
  d1 <- t(filtro.row.matrix(d1, match(genes, rownames(d1))))
  reg2 <- sapply(reg2, function(x, genes) x[match(genes, names(x))], genes=genes)
  reg2[is.na(reg2)] <- 0
  es <- ((d1 %*% reg2)+t(d2 %*% reg1))/sqrt(8*nn)
  if (nes) return(es)
  if (symmetric) return(max(abs(es))-abs(es))
  return(max(es)-es)
}

scaleGroups <- function(dset, groups) {
  colnames(dset) <- groups
  res <- sapply(unique(groups), function(x, dset) {
    x1 <- dset[, colnames(dset)==x]
    x2 <- dset[, colnames(dset)!=x]
    if (is.null(ncol(x1)) | is.null(ncol(x2))) tmp <- f.rtt.na(x1-x2, alternative="two.sided")
    else tmp <- f.rtt.na(x1, x2, alternative="two.sided")
    return((qnorm(tmp$p.value/2, lower.tail=F)*sign(tmp$statistic))[, 1])
  }, dset=dset)
  mm <- max(abs(res)[is.finite(res)])
  ipos <- which(is.infinite(res))
  res[ipos] <- mm+runif(length(ipos), 0, 10)
  return(res)
}
